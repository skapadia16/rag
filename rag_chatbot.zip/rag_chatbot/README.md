# 📄 Local RAG PDF Chatbot

A **completely local** Retrieval-Augmented Generation (RAG) chatbot that lets you
upload a PDF and ask questions about it. Every step — text extraction, chunking,
embeddings, vector search, and answer generation — runs **on your own machine**
using **open-source Hugging Face models**.

- ❌ No OpenAI, Anthropic, Gemini, or any paid API
- ❌ No cloud deployment, no external services
- ✅ Runs fully offline after the first model download
- ✅ CPU-friendly by default, automatically uses GPU if available

---

## How it works

```
PDF upload  →  PyMuPDF text extraction  →  chunking (with page numbers)
           →  sentence-transformers embeddings  →  FAISS vector index
           →  similarity search (top-k)  →  local HF LLM generates answer
           →  answer + page citations shown in the chat
```

The assistant only answers using text retrieved from your PDF. If the
retrieved chunks aren't relevant enough, it tells you the answer isn't in
the document instead of guessing (hallucination control via a similarity
threshold + a strict prompt).

---

## Project structure

```
local_rag_chatbot/
├── app.py                  # Streamlit UI (entry point)
├── requirements.txt
├── .streamlit/
│   └── config.toml         # dark theme by default
├── data/
│   ├── uploads/            # (runtime) uploaded PDFs
│   └── vectorstore/        # (runtime) saved FAISS indexes
└── src/
    ├── config.py           # all tunable settings live here
    ├── pdf_processor.py    # PyMuPDF text extraction
    ├── text_chunker.py     # chunking with page-level metadata
    ├── embeddings.py       # sentence-transformers wrapper
    ├── vector_store.py     # FAISS index wrapper (save/load)
    ├── llm_engine.py       # local Hugging Face text generation
    ├── rag_engine.py       # ties retrieval + generation together
    └── utils.py            # validation helpers
```

---

## 1. Prerequisites

- Python 3.10 – 3.12
- ~5–10 GB free disk space (for model weights, depending on which LLM you pick)
- (Optional) an NVIDIA GPU + CUDA for faster generation — CPU works fine too

---

## 2. Setup — Windows

```powershell
# 1. Clone / unzip the project, then open PowerShell in the project folder
cd local_rag_chatbot

# 2. Create and activate a virtual environment
python -m venv venv
venv\Scripts\activate

# 3. Install dependencies
pip install -r requirements.txt

# (Optional, for GPU acceleration on Windows with an NVIDIA card)
# Install the CUDA build of torch instead of the CPU-only default, e.g.:
# pip install torch --index-url https://download.pytorch.org/whl/cu121

# 4. Run the app
streamlit run app.py
```

## 2. Setup — Linux / macOS

```bash
# 1. Clone / unzip the project
cd local_rag_chatbot

# 2. Create and activate a virtual environment
python3 -m venv venv
source venv/bin/activate

# 3. Install dependencies
pip install -r requirements.txt

# (Optional, for GPU acceleration on Linux with an NVIDIA card)
# pip install torch --index-url https://download.pytorch.org/whl/cu121

# 4. Run the app
streamlit run app.py
```

The app will open at **http://localhost:8501**.

> **First run note:** the first time you upload a PDF or select a model,
> Hugging Face will download the model weights (a few hundred MB to a
> few GB depending on the model). This requires an internet connection
> once; after that, everything runs offline.

---

## 3. Using the app

1. Open the sidebar and (optionally) pick your embedding/LLM models under
   **⚙️ Model settings**.
2. Upload one or more PDFs (max **10 MB** each). You'll see a progress bar
   and a confirmation with page/chunk counts.
3. Ask questions in the chat box. Each answer shows **source badges**
   (filename + page number + similarity score) — expand "View source
   excerpts" to see the exact text used.
4. Use **🗑️ Clear chat & documents** in the sidebar to reset the session.

---

## 4. Model choices

### Embedding models (all local, via `sentence-transformers`)
| Model | Notes |
|---|---|
| `all-MiniLM-L6-v2` | Fastest, ~80MB, good default for CPU |
| `bge-small-en-v1.5` | Better retrieval quality, still light |
| `all-mpnet-base-v2` | Best quality, slower, ~420MB |

### Language models (all local, via `transformers`)
| Model | Notes |
|---|---|
| `google/flan-t5-base` | Fast, CPU-friendly, good for short factual answers |
| `google/flan-t5-large` | Better quality, still CPU-runnable |
| `Qwen/Qwen2.5-1.5B-Instruct` | Chat-quality answers, GPU recommended |
| `microsoft/Phi-3-mini-4k-instruct` | Best quality, GPU strongly recommended |

You can freely swap in any other open-source Hugging Face model by editing
`LLM_MODELS` / `EMBEDDING_MODELS` in `src/config.py`.

---

## 5. Configuration

All tunables live in `src/config.py`:

- `MAX_PDF_SIZE_MB` — upload size limit (default: 10 MB)
- `CHUNK_SIZE` / `CHUNK_OVERLAP` — text chunking parameters
- `TOP_K` — how many chunks are retrieved per question
- `MIN_SIMILARITY_SCORE` — hallucination guard: chunks below this cosine
  similarity are ignored, and if nothing passes the bar the assistant
  says it can't find the answer in the document
- `MAX_NEW_TOKENS` — max length of generated answers

---

## 6. Troubleshooting

- **"No extractable text found"** — the PDF is likely scanned images with
  no text layer. This project doesn't include OCR; you'd need to add a
  tool like `pytesseract` for that.
- **Out of memory / very slow generation** — pick a smaller model
  (`Flan-T5-Base` is the lightest) or reduce `MAX_NEW_TOKENS` in
  `src/config.py`.
- **Model download fails** — check your internet connection; Hugging Face
  Hub access is required the first time each model is used.
- **Port already in use** — run `streamlit run app.py --server.port 8502`.

---

## 7. Privacy

Nothing you upload or ask ever leaves your machine. All processing —
text extraction, embeddings, retrieval, and generation — happens locally
using the open-source models downloaded from Hugging Face.
