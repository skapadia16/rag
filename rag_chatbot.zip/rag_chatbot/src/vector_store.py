"""
Local vector storage and similarity search using FAISS.
Runs entirely in-process/on-disk - no external database or service needed.
"""
import os
import pickle
from typing import List, Tuple
import numpy as np
import faiss

from src.text_chunker import Chunk


class VectorStore:
    """
    Thin wrapper around a FAISS flat inner-product index (cosine similarity,
    since embeddings are L2-normalized) plus the metadata needed to map
    a hit back to its source chunk.
    """

    def __init__(self, dimension: int):
        self.dimension = dimension
        self.index = faiss.IndexFlatIP(dimension)
        self.chunks: List[Chunk] = []

    def add(self, embeddings: np.ndarray, chunks: List[Chunk]) -> None:
        if embeddings.shape[0] != len(chunks):
            raise ValueError("Number of embeddings must match number of chunks.")
        self.index.add(embeddings)
        self.chunks.extend(chunks)

    def search(self, query_embedding: np.ndarray, top_k: int) -> List[Tuple[Chunk, float]]:
        """Returns a list of (chunk, similarity_score) sorted best-first."""
        if self.index.ntotal == 0:
            return []
        top_k = min(top_k, self.index.ntotal)
        scores, indices = self.index.search(query_embedding, top_k)
        results = []
        for score, idx in zip(scores[0], indices[0]):
            if idx == -1:
                continue
            results.append((self.chunks[idx], float(score)))
        return results

    @property
    def num_chunks(self) -> int:
        return len(self.chunks)

    def save(self, directory: str) -> None:
        os.makedirs(directory, exist_ok=True)
        faiss.write_index(self.index, os.path.join(directory, "index.faiss"))
        with open(os.path.join(directory, "chunks.pkl"), "wb") as f:
            pickle.dump(self.chunks, f)

    @classmethod
    def load(cls, directory: str, dimension: int) -> "VectorStore":
        store = cls(dimension)
        index_path = os.path.join(directory, "index.faiss")
        chunks_path = os.path.join(directory, "chunks.pkl")
        if os.path.exists(index_path) and os.path.exists(chunks_path):
            store.index = faiss.read_index(index_path)
            with open(chunks_path, "rb") as f:
                store.chunks = pickle.load(f)
        return store
