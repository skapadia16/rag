"""
Small shared utilities: validation, hashing, formatting.
"""
import hashlib
from src.config import MAX_PDF_SIZE_BYTES, MAX_PDF_SIZE_MB


class PDFValidationError(Exception):
    """Raised when an uploaded PDF fails validation."""
    pass


def validate_pdf(file_bytes: bytes, filename: str) -> None:
    """
    Validate an uploaded PDF before we touch it.
    Raises PDFValidationError with a user-friendly message on failure.
    """
    if not filename.lower().endswith(".pdf"):
        raise PDFValidationError(f"'{filename}' is not a PDF file.")

    if len(file_bytes) == 0:
        raise PDFValidationError(f"'{filename}' is empty.")

    if len(file_bytes) > MAX_PDF_SIZE_BYTES:
        size_mb = len(file_bytes) / (1024 * 1024)
        raise PDFValidationError(
            f"'{filename}' is {size_mb:.1f} MB, which exceeds the "
            f"{MAX_PDF_SIZE_MB} MB limit."
        )

    # Basic magic-byte check that it's actually a PDF
    if not file_bytes[:5] == b"%PDF-":
        raise PDFValidationError(f"'{filename}' does not look like a valid PDF file.")


def file_hash(file_bytes: bytes) -> str:
    """Short, stable hash used to identify a document across a session."""
    return hashlib.sha256(file_bytes).hexdigest()[:12]


def format_bytes(num_bytes: int) -> str:
    size = float(num_bytes)
    for unit in ("B", "KB", "MB", "GB"):
        if size < 1024:
            return f"{size:.1f} {unit}"
        size /= 1024
    return f"{size:.1f} TB"
