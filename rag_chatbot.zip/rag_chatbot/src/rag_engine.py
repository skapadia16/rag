"""
Ties together PDF processing, chunking, embedding, retrieval and local
generation into one RAG pipeline. Designed to answer ONLY from the
uploaded documents and to say so clearly when it can't.
"""
from dataclasses import dataclass, field
from typing import List, Dict, Optional

from src.pdf_processor import extract_pages, get_page_count
from src.text_chunker import chunk_document, Chunk
from src.embeddings import EmbeddingEngine
from src.vector_store import VectorStore
from src.llm_engine import LocalLLM
from src.config import TOP_K, MIN_SIMILARITY_SCORE, MAX_CONTEXT_CHARS
from src.utils import validate_pdf, file_hash


PROMPT_TEMPLATE = """You are a helpful assistant that answers questions using ONLY the context below, which was extracted from the user's uploaded PDF document(s).

Rules:
- Answer strictly using the information in the context.
- If the context does not contain the answer, respond exactly with: "I couldn't find this information in the uploaded document(s)."
- Do not use any outside knowledge.
- Be concise and accurate.

Context:
{context}

Question: {question}

Answer:"""


@dataclass
class Source:
    filename: str
    page_number: int
    snippet: str
    score: float


@dataclass
class DocumentInfo:
    filename: str
    num_pages: int
    num_chunks: int
    size_bytes: int


@dataclass
class RAGEngine:
    embedding_engine: EmbeddingEngine
    llm: LocalLLM
    vector_store: Optional[VectorStore] = None
    documents: Dict[str, DocumentInfo] = field(default_factory=dict)

    def add_pdf(self, file_bytes: bytes, filename: str) -> DocumentInfo:
        """Validate, extract, chunk, embed and index a PDF."""
        validate_pdf(file_bytes, filename)

        doc_key = f"{filename}-{file_hash(file_bytes)}"
        pages = extract_pages(file_bytes)
        if not pages:
            raise ValueError(
                f"No extractable text found in '{filename}'. "
                "It may be a scanned/image-only PDF."
            )

        chunks: List[Chunk] = chunk_document(pages, source=filename)
        texts = [c.text for c in chunks]
        embeddings = self.embedding_engine.embed_texts(texts)

        if self.vector_store is None:
            self.vector_store = VectorStore(dimension=embeddings.shape[1])
        self.vector_store.add(embeddings, chunks)

        info = DocumentInfo(
            filename=filename,
            num_pages=get_page_count(file_bytes),
            num_chunks=len(chunks),
            size_bytes=len(file_bytes),
        )
        self.documents[doc_key] = info
        return info

    def has_documents(self) -> bool:
        return self.vector_store is not None and self.vector_store.num_chunks > 0

    def answer(self, question: str) -> Dict:
        """
        Retrieve relevant chunks and generate a grounded answer.
        Returns {"answer": str, "sources": List[Source]}.
        """
        if not self.has_documents():
            return {
                "answer": "Please upload a PDF document first so I have something to answer from.",
                "sources": [],
            }

        query_embedding = self.embedding_engine.embed_query(question)
        results = self.vector_store.search(query_embedding, top_k=TOP_K)

        # Filter out weak matches so we don't hallucinate from irrelevant text
        relevant = [(c, s) for c, s in results if s >= MIN_SIMILARITY_SCORE]

        if not relevant:
            return {
                "answer": "I couldn't find this information in the uploaded document(s).",
                "sources": [],
            }

        context_parts = []
        total_len = 0
        sources: List[Source] = []
        for chunk, score in relevant:
            if total_len >= MAX_CONTEXT_CHARS:
                break
            snippet = chunk.text[:600]
            context_parts.append(
                f"[Source: {chunk.source}, Page {chunk.page_number}]\n{chunk.text}"
            )
            total_len += len(chunk.text)
            sources.append(
                Source(
                    filename=chunk.source,
                    page_number=chunk.page_number,
                    snippet=snippet,
                    score=score,
                )
            )

        context = "\n\n---\n\n".join(context_parts)
        prompt = PROMPT_TEMPLATE.format(context=context, question=question)

        raw_answer = self.llm.generate(prompt)

        return {"answer": raw_answer, "sources": sources}

    def clear(self) -> None:
        self.vector_store = None
        self.documents = {}
