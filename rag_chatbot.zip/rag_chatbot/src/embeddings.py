"""
Local, open-source embedding generation via sentence-transformers.
No API calls, no paid services - the model weights are downloaded once
from the Hugging Face Hub and then run entirely on your machine.
"""
from typing import List
import numpy as np
from sentence_transformers import SentenceTransformer
from src.config import DEVICE


class EmbeddingEngine:
    def __init__(self, model_name: str):
        self.model_name = model_name
        self.model = SentenceTransformer(model_name, device=DEVICE)

    def embed_texts(self, texts: List[str]) -> np.ndarray:
        """Embed a batch of document chunks. Returns L2-normalized vectors."""
        embeddings = self.model.encode(
            texts,
            batch_size=32,
            show_progress_bar=False,
            convert_to_numpy=True,
            normalize_embeddings=True,  # so we can use inner product = cosine sim
        )
        return embeddings.astype("float32")

    def embed_query(self, query: str) -> np.ndarray:
        embedding = self.model.encode(
            [query],
            convert_to_numpy=True,
            normalize_embeddings=True,
        )
        return embedding.astype("float32")
