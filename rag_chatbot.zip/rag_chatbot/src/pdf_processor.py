"""
PDF text extraction using PyMuPDF (fitz).
Keeps text tied to its page number so we can cite sources later.
"""
from dataclasses import dataclass
from typing import List
import fitz  # PyMuPDF


@dataclass
class PageText:
    page_number: int   # 1-indexed, human friendly
    text: str


def extract_pages(file_bytes: bytes) -> List[PageText]:
    """
    Extract text from every page of a PDF given as raw bytes.
    Returns a list of PageText, skipping pages with no extractable text.
    """
    pages: List[PageText] = []
    with fitz.open(stream=file_bytes, filetype="pdf") as doc:
        for i, page in enumerate(doc):
            text = page.get_text("text").strip()
            if text:
                pages.append(PageText(page_number=i + 1, text=text))
    return pages


def get_page_count(file_bytes: bytes) -> int:
    with fitz.open(stream=file_bytes, filetype="pdf") as doc:
        return doc.page_count
