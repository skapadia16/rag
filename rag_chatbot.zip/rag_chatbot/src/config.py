"""
Central configuration for the Local RAG Chatbot.
All tunable parameters live here so the rest of the codebase stays clean.
"""
import os
import torch

# --------------------------------------------------------------------------
# Paths
# --------------------------------------------------------------------------
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(BASE_DIR, "data")
UPLOAD_DIR = os.path.join(DATA_DIR, "uploads")
VECTORSTORE_DIR = os.path.join(DATA_DIR, "vectorstore")

os.makedirs(UPLOAD_DIR, exist_ok=True)
os.makedirs(VECTORSTORE_DIR, exist_ok=True)

# --------------------------------------------------------------------------
# Upload limits
# --------------------------------------------------------------------------
MAX_PDF_SIZE_MB = 10
MAX_PDF_SIZE_BYTES = MAX_PDF_SIZE_MB * 1024 * 1024

# --------------------------------------------------------------------------
# Chunking
# --------------------------------------------------------------------------
CHUNK_SIZE = 800          # characters per chunk
CHUNK_OVERLAP = 150       # overlap between consecutive chunks

# --------------------------------------------------------------------------
# Retrieval / hallucination control
# --------------------------------------------------------------------------
TOP_K = 4                       # number of chunks retrieved per query
MIN_SIMILARITY_SCORE = 0.30     # cosine similarity threshold (0-1).
                                 # Below this, we tell the user the answer
                                 # isn't in the document instead of guessing.
MAX_CONTEXT_CHARS = 3500        # cap on how much retrieved text we feed the LLM

# --------------------------------------------------------------------------
# Device
# --------------------------------------------------------------------------
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
TORCH_DTYPE = torch.float16 if DEVICE == "cuda" else torch.float32

# --------------------------------------------------------------------------
# Embedding models (all open-source, run locally via sentence-transformers)
# --------------------------------------------------------------------------
EMBEDDING_MODELS = {
    "all-MiniLM-L6-v2 (fast, 80MB)": "sentence-transformers/all-MiniLM-L6-v2",
    "bge-small-en-v1.5 (better quality, 130MB)": "BAAI/bge-small-en-v1.5",
    "all-mpnet-base-v2 (best quality, 420MB)": "sentence-transformers/all-mpnet-base-v2",
}
DEFAULT_EMBEDDING_MODEL = "all-MiniLM-L6-v2 (fast, 80MB)"

# --------------------------------------------------------------------------
# Local LLMs (all open-source Hugging Face models, no paid API)
# Sizes are approximate download sizes.
# --------------------------------------------------------------------------
LLM_MODELS = {
    "Flan-T5-Base (fast, CPU-friendly, ~250MB)": {
        "repo_id": "google/flan-t5-base",
        "type": "seq2seq",
    },
    "Flan-T5-Large (better quality, ~780MB)": {
        "repo_id": "google/flan-t5-large",
        "type": "seq2seq",
    },
    "Qwen2.5-1.5B-Instruct (chat-quality, GPU recommended, ~3GB)": {
        "repo_id": "Qwen/Qwen2.5-1.5B-Instruct",
        "type": "causal",
    },
    "Phi-3-mini-4k-instruct (best quality, GPU strongly recommended, ~7.6GB)": {
        "repo_id": "microsoft/Phi-3-mini-4k-instruct",
        "type": "causal",
    },
}

# Sensible default: lighter model on CPU, better model if a GPU is present.
DEFAULT_LLM_MODEL = (
    "Qwen2.5-1.5B-Instruct (chat-quality, GPU recommended, ~3GB)"
    if DEVICE == "cuda"
    else "Flan-T5-Base (fast, CPU-friendly, ~250MB)"
)

MAX_NEW_TOKENS = 400
