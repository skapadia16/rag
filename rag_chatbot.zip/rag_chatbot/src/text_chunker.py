"""
Splits page text into overlapping chunks while preserving page number and
source filename metadata, so every chunk can later be cited accurately.
"""
from dataclasses import dataclass
from typing import List
from src.pdf_processor import PageText
from src.config import CHUNK_SIZE, CHUNK_OVERLAP


@dataclass
class Chunk:
    text: str
    source: str
    page_number: int
    chunk_id: str


def _split_text(text: str, chunk_size: int, overlap: int) -> List[str]:
    """
    Simple recursive-ish character splitter: tries to break on paragraph,
    then sentence, then hard character boundaries, keeping an overlap
    between consecutive chunks so context isn't lost at the edges.
    """
    if len(text) <= chunk_size:
        return [text]

    separators = ["\n\n", "\n", ". ", " "]
    chunks: List[str] = []
    start = 0
    text_len = len(text)

    while start < text_len:
        end = min(start + chunk_size, text_len)

        if end < text_len:
            # try to end on a natural boundary within the window
            window = text[start:end]
            best_cut = -1
            for sep in separators:
                idx = window.rfind(sep)
                if idx != -1:
                    best_cut = idx + len(sep)
                    break
            if best_cut != -1 and best_cut > chunk_size * 0.5:
                end = start + best_cut

        chunk = text[start:end].strip()
        if chunk:
            chunks.append(chunk)

        if end >= text_len:
            break
        start = max(end - overlap, start + 1)

    return chunks


def chunk_document(pages: List[PageText], source: str) -> List[Chunk]:
    """
    Turn a list of PageText into overlapping Chunks, tagged with the
    originating filename and page number for citation purposes.
    """
    chunks: List[Chunk] = []
    for page in pages:
        pieces = _split_text(page.text, CHUNK_SIZE, CHUNK_OVERLAP)
        for i, piece in enumerate(pieces):
            chunk_id = f"{source}::p{page.page_number}::c{i}"
            chunks.append(
                Chunk(
                    text=piece,
                    source=source,
                    page_number=page.page_number,
                    chunk_id=chunk_id,
                )
            )
    return chunks
