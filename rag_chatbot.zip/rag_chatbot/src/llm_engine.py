"""
Local text generation using open-source Hugging Face models via
transformers. No OpenAI / Anthropic / Gemini / paid API calls anywhere.

Supports two model families:
  - "seq2seq": encoder-decoder models like Flan-T5 (fast, CPU-friendly)
  - "causal":  decoder-only chat models like Qwen2.5-Instruct, Phi-3-mini
"""
import torch
from transformers import (
    AutoTokenizer,
    AutoModelForSeq2SeqLM,
    AutoModelForCausalLM,
)
from src.config import DEVICE, TORCH_DTYPE, MAX_NEW_TOKENS


class LocalLLM:
    def __init__(self, repo_id: str, model_type: str):
        self.repo_id = repo_id
        self.model_type = model_type
        self.tokenizer = AutoTokenizer.from_pretrained(repo_id)

        load_kwargs = {"torch_dtype": TORCH_DTYPE}

        if model_type == "seq2seq":
            self.model = AutoModelForSeq2SeqLM.from_pretrained(repo_id, **load_kwargs)
        else:
            self.model = AutoModelForCausalLM.from_pretrained(repo_id, **load_kwargs)

        self.model.to(DEVICE)
        self.model.eval()

    @torch.inference_mode()
    def generate(self, prompt: str, max_new_tokens: int = MAX_NEW_TOKENS) -> str:
        if self.model_type == "causal" and hasattr(self.tokenizer, "apply_chat_template"):
            messages = [{"role": "user", "content": prompt}]
            input_ids = self.tokenizer.apply_chat_template(
                messages, add_generation_prompt=True, return_tensors="pt"
            ).to(DEVICE)
            output = self.model.generate(
                input_ids,
                max_new_tokens=max_new_tokens,
                do_sample=False,
                temperature=None,
                top_p=None,
                pad_token_id=self.tokenizer.eos_token_id,
            )
            generated = output[0][input_ids.shape[-1]:]
            return self.tokenizer.decode(generated, skip_special_tokens=True).strip()

        # seq2seq (Flan-T5) or causal model without a chat template
        inputs = self.tokenizer(prompt, return_tensors="pt", truncation=True, max_length=2048).to(DEVICE)
        output = self.model.generate(
            **inputs,
            max_new_tokens=max_new_tokens,
            do_sample=False,
        )
        if self.model_type == "seq2seq":
            return self.tokenizer.decode(output[0], skip_special_tokens=True).strip()
        else:
            generated = output[0][inputs["input_ids"].shape[-1]:]
            return self.tokenizer.decode(generated, skip_special_tokens=True).strip()
