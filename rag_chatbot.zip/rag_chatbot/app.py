"""
Local RAG PDF Chatbot - Streamlit frontend.

100% local: PDF parsing, embeddings, vector search and text generation
all run on your own machine using open-source Hugging Face models.
No OpenAI / Anthropic / Gemini / paid API calls are made anywhere.
"""
import time
import streamlit as st

from src.config import (
    EMBEDDING_MODELS,
    DEFAULT_EMBEDDING_MODEL,
    LLM_MODELS,
    DEFAULT_LLM_MODEL,
    MAX_PDF_SIZE_MB,
    DEVICE,
)
from src.embeddings import EmbeddingEngine
from src.llm_engine import LocalLLM
from src.rag_engine import RAGEngine
from src.utils import PDFValidationError, format_bytes

# ---------------------------------------------------------------------------
# Page setup
# ---------------------------------------------------------------------------
st.set_page_config(
    page_title="Local RAG PDF Chatbot",
    page_icon="📄",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ---------------------------------------------------------------------------
# Light styling on top of the base theme (bubble chat look, subtle polish)
# ---------------------------------------------------------------------------
st.markdown(
    """
    <style>
    .stChatMessage { border-radius: 14px; }
    .source-badge {
        display: inline-block;
        padding: 2px 10px;
        margin: 3px 4px 0 0;
        border-radius: 999px;
        background: rgba(108, 92, 231, 0.18);
        border: 1px solid rgba(108, 92, 231, 0.5);
        font-size: 0.78rem;
    }
    .doc-card {
        padding: 10px 14px;
        border-radius: 10px;
        background: rgba(255,255,255,0.04);
        border: 1px solid rgba(255,255,255,0.08);
        margin-bottom: 8px;
    }
    .status-pill {
        padding: 2px 10px;
        border-radius: 999px;
        font-size: 0.75rem;
        background: rgba(46, 204, 113, 0.15);
        border: 1px solid rgba(46, 204, 113, 0.4);
    }
    </style>
    """,
    unsafe_allow_html=True,
)

# ---------------------------------------------------------------------------
# Cached model loaders (loaded once per model choice, kept warm in memory)
# ---------------------------------------------------------------------------
@st.cache_resource(show_spinner=False)
def load_embedding_engine(model_label: str) -> EmbeddingEngine:
    return EmbeddingEngine(EMBEDDING_MODELS[model_label])


@st.cache_resource(show_spinner=False)
def load_llm(model_label: str) -> LocalLLM:
    cfg = LLM_MODELS[model_label]
    return LocalLLM(repo_id=cfg["repo_id"], model_type=cfg["type"])


# ---------------------------------------------------------------------------
# Session state init
# ---------------------------------------------------------------------------
if "messages" not in st.session_state:
    st.session_state.messages = []  # list of {"role", "content", "sources"}
if "rag_engine" not in st.session_state:
    st.session_state.rag_engine = None
if "processed_files" not in st.session_state:
    st.session_state.processed_files = set()
if "embedding_choice" not in st.session_state:
    st.session_state.embedding_choice = DEFAULT_EMBEDDING_MODEL
if "llm_choice" not in st.session_state:
    st.session_state.llm_choice = DEFAULT_LLM_MODEL


def get_rag_engine() -> RAGEngine:
    """(Re)build the RAG engine if the model choices changed."""
    key = (st.session_state.embedding_choice, st.session_state.llm_choice)
    if st.session_state.rag_engine is None or st.session_state.get("_engine_key") != key:
        with st.spinner("Loading local models (first run downloads weights, please wait)..."):
            embedding_engine = load_embedding_engine(st.session_state.embedding_choice)
            llm = load_llm(st.session_state.llm_choice)
            engine = RAGEngine(embedding_engine=embedding_engine, llm=llm)
        st.session_state.rag_engine = engine
        st.session_state._engine_key = key
        st.session_state.processed_files = set()
    return st.session_state.rag_engine


# ---------------------------------------------------------------------------
# Sidebar: model config, upload, document info, clear chat
# ---------------------------------------------------------------------------
with st.sidebar:
    st.markdown("## 📄 Local RAG Chatbot")
    st.caption(f"Running on **{DEVICE.upper()}** · 100% local · no paid APIs")

    with st.expander("⚙️ Model settings", expanded=False):
        st.selectbox(
            "Embedding model",
            list(EMBEDDING_MODELS.keys()),
            key="embedding_choice",
            help="Converts text into vectors for similarity search.",
        )
        st.selectbox(
            "Language model (generation)",
            list(LLM_MODELS.keys()),
            key="llm_choice",
            help="Generates answers from the retrieved document text.",
        )
        st.caption(
            "Changing a model reloads it into memory and clears the current "
            "document index (you'll need to re-upload your PDF)."
        )

    st.divider()
    st.markdown("### 📤 Upload PDF(s)")
    st.caption(f"Max file size: {MAX_PDF_SIZE_MB} MB per file")

    uploaded_files = st.file_uploader(
        "Choose PDF file(s)",
        type=["pdf"],
        accept_multiple_files=True,
        label_visibility="collapsed",
    )

    if uploaded_files:
        engine = get_rag_engine()
        for uploaded_file in uploaded_files:
            if uploaded_file.name in st.session_state.processed_files:
                continue
            file_bytes = uploaded_file.getvalue()

            progress = st.progress(0, text=f"Reading {uploaded_file.name}...")
            try:
                progress.progress(25, text=f"Extracting text from {uploaded_file.name}...")
                time.sleep(0.05)
                progress.progress(55, text=f"Chunking {uploaded_file.name}...")
                time.sleep(0.05)
                progress.progress(75, text=f"Embedding {uploaded_file.name} (local model)...")
                info = engine.add_pdf(file_bytes, uploaded_file.name)
                progress.progress(100, text="Done!")
                time.sleep(0.2)
                progress.empty()

                st.session_state.processed_files.add(uploaded_file.name)
                st.success(f"✅ Indexed **{uploaded_file.name}** ({info.num_pages} pages, {info.num_chunks} chunks)")
            except PDFValidationError as e:
                progress.empty()
                st.error(f"❌ {e}")
            except ValueError as e:
                progress.empty()
                st.error(f"❌ {e}")
            except Exception as e:
                progress.empty()
                st.error(f"❌ Unexpected error processing {uploaded_file.name}: {e}")

    st.divider()
    st.markdown("### 📚 Document info")
    engine = st.session_state.rag_engine
    if engine and engine.documents:
        for info in engine.documents.values():
            st.markdown(
                f"""
                <div class="doc-card">
                <b>{info.filename}</b><br>
                <span class="status-pill">indexed</span><br>
                📄 {info.num_pages} pages &nbsp;·&nbsp; 🧩 {info.num_chunks} chunks &nbsp;·&nbsp; 💾 {format_bytes(info.size_bytes)}
                </div>
                """,
                unsafe_allow_html=True,
            )
    else:
        st.caption("No documents uploaded yet.")

    st.divider()
    if st.button("🗑️ Clear chat & documents", use_container_width=True):
        st.session_state.messages = []
        if st.session_state.rag_engine:
            st.session_state.rag_engine.clear()
        st.session_state.processed_files = set()
        st.rerun()

# ---------------------------------------------------------------------------
# Main chat area
# ---------------------------------------------------------------------------
st.markdown("# 💬 Chat with your PDFs")
st.caption(
    "Answers are generated **only** from the content of your uploaded PDF(s). "
    "If the answer isn't in the document, the assistant will say so instead of guessing."
)

# Render chat history
for msg in st.session_state.messages:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])
        if msg.get("sources"):
            badges = "".join(
                f'<span class="source-badge">📄 {s.filename} · p.{s.page_number} '
                f"({s.score:.2f})</span>"
                for s in msg["sources"]
            )
            st.markdown(badges, unsafe_allow_html=True)
            with st.expander("View source excerpts"):
                for s in msg["sources"]:
                    st.markdown(f"**{s.filename} — page {s.page_number}** (similarity {s.score:.2f})")
                    st.text(s.snippet)

# Chat input
question = st.chat_input("Ask a question about your uploaded PDF(s)...")

if question:
    engine = get_rag_engine()

    st.session_state.messages.append({"role": "user", "content": question, "sources": None})
    with st.chat_message("user"):
        st.markdown(question)

    with st.chat_message("assistant"):
        with st.spinner("Thinking through the document..."):
            result = engine.answer(question)
        st.markdown(result["answer"])
        if result["sources"]:
            badges = "".join(
                f'<span class="source-badge">📄 {s.filename} · p.{s.page_number} '
                f"({s.score:.2f})</span>"
                for s in result["sources"]
            )
            st.markdown(badges, unsafe_allow_html=True)
            with st.expander("View source excerpts"):
                for s in result["sources"]:
                    st.markdown(f"**{s.filename} — page {s.page_number}** (similarity {s.score:.2f})")
                    st.text(s.snippet)

    st.session_state.messages.append(
        {"role": "assistant", "content": result["answer"], "sources": result["sources"]}
    )

if not st.session_state.messages:
    st.info("👈 Upload a PDF from the sidebar to get started, then ask a question here.")
